#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
	int fd;
	char buff[10];

	mkfifo("f1",0666);
	perror("mkfifo");
	fd=open("f1",O_WRONLY);
	perror("open");

	do
	{
		printf("enter the data\n");
		scanf("%s",buff);
		write(fd,buff,strlen(buff)+1);
		perror("write");
	}while(1);
}
