#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
	int fd1;
	char buff[10];

	fd1=open("f1",O_RDONLY);
	perror("open");

	while(1)
	{
		read(fd1,buff,sizeof(buff));
		printf("read data =%s\n",buff);
	}
}
