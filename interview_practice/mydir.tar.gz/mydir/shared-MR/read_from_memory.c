#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#define SIZE 1024

int main()
{
	key_t key=ftok("shmfile",65);
	int shmid=shmget(key,SIZE,0666|IPC_CREAT);

	char *str=(char*)shmat(shmid,(void*)0,0);
	printf("data read from memory: %s\n",str);

	shmdt(str);
	shmctl(shmid,IPC_RMID,NULL);
	return 0;
}

/* 
 * Flag:
 * IPC_RMID: Remove the shared memory segment */
