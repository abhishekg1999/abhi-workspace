## how to run write and read both cases 

1. first run write program and then after termination of write program then run read program.
2. first prog will write data into memory and detach from memory.
3. but 2nd prog will read , detach and delete the memory.
