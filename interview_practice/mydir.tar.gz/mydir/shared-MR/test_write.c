#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main(int argc,char **argv)
{
	int id;
	char *p;

	id=shmget(atoi(argv[1]),atoi(argv[2]),IPC|0666);
	perror("shmget");

	p=shmat(id,0,0);
	perror("shmat");
	printf("shared-memory =%u\n",p);

	printf("enter the data\n");
	scanf("%s",p);

	shmdt(p);
	perror("shmdt");
}
