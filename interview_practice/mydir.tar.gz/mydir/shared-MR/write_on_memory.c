#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#define SIZE 10
int main()
{
	key_t key=ftok("shmfile",65);
	int shmid=shmget(key,1024,0666|IPC_CREAT);

	char *str=(char*)shmat(shmid,(void*)0,0);
	printf("write data\n");
	fgets(str,SIZE,stdin);

	printf("data write on memory: %s\n",str);
	shmdt(str);
	return 0;
}
