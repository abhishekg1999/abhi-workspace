## how to compile and run thread program.

* first compile program with -lpthread option .
* run the program.
