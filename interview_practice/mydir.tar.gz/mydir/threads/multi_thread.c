#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

int count=0;
void* FirstThread(void *ptr)
{
	int i;
	for(i=0;i<10;i++)
	{
		count++;
		printf("In thread 1 count=%d\n",count);
	}
	return 0;
}

void* SecThread(void *ptr)
{
	int i;
	for(i=0;i<10;i++)
	{
		count++;
		printf("In thread 2 count=%d\n",count);
	}
	return 0;
}

int main()
{
	pthread_t tid1,tid2;

	pthread_create(&tid1,NULL,FirstThread,NULL);
	pthread_create(&tid2,NULL,SecThread,NULL);

	pthread_join(tid1,0);
	pthread_join(tid2,0);
	return 0;
}
