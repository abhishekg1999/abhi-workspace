#include <stdio.h>
#include <stdlib.h> // exit()
#include <unistd.h> //fork(),write()
#include <fcntl.h>   // open()
#include <sys/wait.h> //wait()
#include <sys/sem.h> //semget(),semctl(),semop()

#define KEY 123
int main()
{
	int semid,fd;
	struct sembuf v;

	/* create semaphore */
	semid=semget(KEY,1,IPC_CREAT|0666);
	fd=open("data",O_CREAT|O_WRONLY); /*create data file and open it */

	/* initialize semaphore with 0 */
	semctl(semid,0,SETVAL,0);
	if(fork()== 0)
	{//child

		/* waiting for semaphore to be release by parent */
		v.sem_num=0;
		v.sem_op=-1;
		v.sem_flg=0;
		semop(semid,&v,1);

		/* critical section */
		for(char ch = 'a';ch<= 'z';ch++)
			write(fd,&ch,1);

		/* release semaphore for parent */
		v.sem_op=1;
		semop(semid,&v,1);
		exit(EXIT_SUCCESS);

	}
	else
	{//parent	
	
		/* critical section */
		for(char ch = 'A';ch<= 'Z';ch++)
                        write(fd,&ch,1);

		/* release semaphore for child */
		v.sem_num=0;
		v.sem_op=1;
		v.sem_flg=0;
		semop(semid,&v,1);
	
		/* wait for child to complete */
		wait(NULL);

		/* remove semaphore */
		semctl(semid,0,IPC_RMID,0);
		exit(EXIT_SUCCESS);
	}
	return 0;
}
