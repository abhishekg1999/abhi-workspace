#include <stdio.h>
#include <pthread.h>

int count=0;
pthread_mutex_t lock; /* define mutex */
void* FirstThread(void *ptr)
{
	int i;
	for(i=0;i<10;i++)
	{
		pthread_mutex_lock(&lock); /* put the mutex lock on thread 1 */
		count++;
		printf("In thread 1 count=%d\n",count);
		pthread_mutex_unlock(&lock); /* release the lock */
	}
	return NULL;
}

void* SecThread(void *ptr)
{
	int i;
	for(i=0;i<10;i++)
	{
		pthread_mutex_lock(&lock); /* put the mutex lock on thread 2 */
		count++;
		printf("In thread 2 count=%d\n",count);
		pthread_mutex_unlock(&lock); /* release the lock */
	}
	return NULL;
}

int main()
{
	pthread_t tid[2];
	pthread_mutex_init(&lock,NULL); /* initialize mutex with zero */

	pthread_create(&tid[0],NULL,FirstThread,NULL);
	pthread_create(&tid[1],NULL,SecThread,NULL);

	pthread_join(tid[0],NULL);
	pthread_join(tid[1],NULL);
	pthread_mutex_destroy(&lock);  /* destroy mutex */
	return 0;
}
