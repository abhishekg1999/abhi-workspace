#include <stdio.h>
#include <pthread.h>


int count=0;
pthread_spinlock_t lock;

void* FirstThread(void *ptr)
{
	int i;
	for(i=0;i<10;i++)
	{
		pthread_spin_lock(&lock);
		count++;
		printf("In thread 1 count=%d\n",count);
		pthread_spin_unlock(&lock);
	}
	return NULL;
}

void* SecThread(void *ptr)
{
	int i;
	for(i=0;i<10;i++)
	{
		pthread_spin_lock(&lock);
		count++;
		printf("In thread 2 count=%d\n",count);
		pthread_spin_unlock(&lock);
	}
	return NULL;
}

int main()
{
	pthread_t tid[2];
	pthread_spin_init(&lock,0);

	pthread_create(&tid[0],NULL,FirstThread,NULL);
	pthread_create(&tid[1],NULL,SecThread,NULL);

	pthread_join(tid[0],NULL);
	pthread_join(tid[1],NULL);
	pthread_spin_destroy(&lock);
	return 0;
}
