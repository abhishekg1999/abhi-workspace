#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

void *FirstThread(void *ptr)
{
	sleep(1);
	printf("I am in thread..\n");
	//pthread_exit("thread exited");
	return 0;
}

int main()
{
	pthread_t tid;
	//void *ptr;
	
	printf("before thread..\n");
	pthread_create(&tid,NULL,FirstThread,NULL);

	pthread_join(tid,NULL);
	printf("after thread..\n");

	//pthread_join(tid,&ptr);
	//printf("%s\n",(char*)ptr);
	return 0;
}
