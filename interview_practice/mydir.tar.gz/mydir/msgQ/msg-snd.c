#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <string.h>
#include <stdlib.h>

struct msgbuf
{
	long mtype;
	char data[10];
};

int main(int argc,char **argv)
{
	struct msgbuf v;
	v.mtype=atoi(argv[1]);
	strcpy(v.data,argv[2]);

	int mid;
	mid=msgget(1,IPC_CREAT|0666);
	if(mid<0)
	{
		perror("msgget");
		return;
	}

	msgsnd(mid,&v,strlen(v.data)+1,0);
	perror("msgsnd");
	return 0;
}
