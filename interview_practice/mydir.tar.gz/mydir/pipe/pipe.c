#include <stdio.h> 
#include <unistd.h> 
#include <string.h>
#include <stdlib.h>

int main()
{
	char rbuf[10],wbuf[10];
	int p[2],pid;

	if(pipe(p)<0)
		exit(1);

	pid=fork();
	if(pid == 0)
	{
		/* child process */
		printf("enter the data to write\n");
		fgets(wbuf,80,stdin);  //it will take 9(char) + 1(\0)
		
		write(p[1],wbuf,strlen(wbuf)+1);  //full string + \0
		close(p[1]);
	}
	else
	{
		/* parent process */
		read(p[0],rbuf,sizeof(rbuf));
		printf("read data: %s\n",rbuf);
		close(p[0]);
	}

	return 0;
}


